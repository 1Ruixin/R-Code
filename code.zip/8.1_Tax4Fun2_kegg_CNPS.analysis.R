

#-----分别提取CNPS基因表格#-----
psko = readRDS("./data/function.prediction/ps_kegg_gene.rds")
# ps01 = readRDS("./data/dataNEW/ps_16s.rds")

ps01 = base::readRDS("./data/ps_16s_soil.rds")

#  定义分组
map = ps01 %>% sample_data()
head(map)
map$Group = map$group

sample_data(psko) = map
otupath = "result_and_plot/CNPS.function.prediction/"
fs::dir_create(otupath)

dat = read.csv("G:\\三人成师-培训资料汇总/第6期/Database/CNPS_Gene_Function/C.csv")
head(dat)
otu = psko %>% 
  scale_micro() %>%
  vegan_otu() %>% t() %>%
  as.data.frame() 
otu$ID = row.names(otu)
head(otu)
C.tab = otu %>% inner_join(dat,by = c("ID" = "K.number"))
head(C.tab)
dim(C.tab)
write.csv(C.tab,paste(otupath,"/C_cycle_imformation.csv",sep = ""),quote = FALSE)

dat = read.csv("G:\\三人成师-培训资料汇总/第6期/Database/CNPS_Gene_Function/N.csv")
otu = psko %>% 
  scale_micro() %>%
  vegan_otu() %>% t() %>%
  as.data.frame() 
otu$ID = row.names(otu)
N.tab = otu %>% inner_join(dat,by = c("ID" = "K.number"))
head(N.tab)
write.csv(N.tab,
          paste(otupath,"./N_cycle_imformation.csv",sep = ""),
          quote = FALSE)

dat = read.csv("G:\\三人成师-培训资料汇总/第6期/Database/CNPS_Gene_Function/P.csv")
otu = psko %>% 
  scale_micro() %>%
  vegan_otu() %>% t() %>%
  as.data.frame() 
otu$ID = row.names(otu)
C.tab = otu %>% inner_join(dat,by = c("ID" = "K.number"))
head(C.tab)
write.csv(C.tab,paste(otupath,"./P_cycle_imformation.csv",sep = ""),quote = FALSE)

dat = read.csv("G:\\三人成师-培训资料汇总/第6期/Database/CNPS_Gene_Function/S.csv")
head(dat)
otu = psko %>% 
  scale_micro() %>%
  vegan_otu() %>% t() %>%
  as.data.frame() 
otu$ID = row.names(otu)
C.tab = otu %>% inner_join(dat,by = c("ID" = "K.number"))
head(C.tab)
write.csv(C.tab,paste(otupath,"./S_cycle_imformation.csv",sep = ""),quote = FALSE)


#--CNPS基因网络#------
library(tidyverse)
library(phyloseq)
library(data.table)
library(ggClusterNet)
library(EasyStat)
library(tidyfst)
library(sna)

netpath = paste(otupath,"/CNPS.network/",sep = "")
dir.create(netpath)
#--提取的基因KO号
dat = read.csv("G:\\三人成师-培训资料汇总/第6期/Database/CNPS_Gene_Function/CNPS-1.1.0-数据库元素循环.csv")
head(dat)
source("E:/Shared_Folder/Function_local/R_function/Metagenome_Function/meta.func/CNPS.network.R")
CNPS.network(ps = psko,dat = dat,path0 = netpath ,id.0 = "C")
CNPS.network(ps = psko,dat = dat,path0  = netpath ,id.0 = "N")
CNPS.network(ps = psko,dat = dat,path0 = netpath ,id.0 = "P")
CNPS.network(ps = psko,dat = dat,path0 = netpath ,id.0 = "S")

#  基于CNPS基因的分析#---------
dat = read.csv("E:/Shared_Folder/Database/CNPS_Gene_Function/CNPS-1.1.0-数据库元素循环.csv")
head(dat)
otu = psko %>% 
  scale_micro() %>%
  vegan_otu() %>% t() %>%
  as.data.frame() 
otu$ID = row.names(otu)
head(otu)
tab= otu %>% inner_join(dat,by = c("ID" = "K.number"))
head(tab)
dim(tab)
# write.csv(C.tab,paste(otupath,"/C_cycle_imformation.csv",sep = ""),quote = FALSE)

map= psko %>% sample_data()
head(map)

tab = tab %>% distinct(Group, ID, .keep_all = TRUE)  
otu = tab[,row.names(map)]
head(otu)
paste0(tab$Group,tab$ID) %>% unique()
row.names(otu) = paste0(tab$Group,tab$ID)



tax= tab[,setdiff(colnames(tab),row.names(map))]
row.names(tax) = paste0(tab$Group,tab$ID)

ps = phyloseq(
  otu_table(as.matrix(otu),taxa_are_rows = TRUE),
  tax_table(as.matrix(tax)),
  sample_data(psko)
)

tax = ps %>% vegan_tax() %>% as.data.frame()
tax$row.id = row.names(tax)
tax_table(ps) = tax_table(as.matrix(tax))

dir.create("./data/function.prediction/")
saveRDS(ps,"./data/function.prediction//ps.CNPS.rds")


ps = readRDS("./data/function.prediction/ps.CNPS.rds")



#--排序分析beta-diversity#----
betapath = paste(otupath,"/beta/",sep = "")
dir.create(betapath)

# "unifrac" "wunifrac" "dpcoa" "jsd" "manhattan" "euclidean"   "canberra" "bray" "kulczynski" 
# "jaccard" "gower" "altGower" "morisita" "horn" "mountford"  "raup" "binomial" 
# "chao"  "cao" "w"  "-1"  "c" "wb"  "r"   "I"  "e" "t" "me"   "j"  "sor"  "m"   "-2"  "co"
# DCA, CCA, RDA, NMDS, MDS, PCoA, PCA, LDA tsne 

source("E:\\Shared_Folder\\Function_local\\R_function\\micro/BetaDiv.R")
source("E:\\Shared_Folder\\Function_local\\R_function\\micro/MicroTest.R")
source("E:\\Shared_Folder\\Function_local\\R_function\\micro/pairMicroTest.R")

methodlist = c("NMDS","PCoA", "PCA")

# methodlist = c("LDA")
for (method in methodlist) {
  result = BetaDiv(ps = ps, group = "Group", dist = "bray",
                   method = method, Micromet = "anosim", pvalue.cutoff = 0.05,
                   pair = F)
  p3_1 = result[[1]] + 
    scale_fill_manual(values = colset1)+
    scale_color_manual(values = colset1,guide = F) +
    mytheme1 
  # theme(legend.position = c(0.2,0.2))
  p3_1
  #带标签图形出图
  p3_2 = result[[3]] +
    scale_fill_manual(values = colset1)+
    scale_color_manual(values = colset1,guide = F) + 
    mytheme1 
  # theme(legend.position = c(0.2,0.2))
  p3_2
  
  FileName <- paste(betapath,"/a2_",method,"bray.pdf", sep = "")
  ggsave(FileName, p3_1, width = 8, height = 7)
  FileName1 <- paste(betapath,"/a2_",method,"",method,"bray.jpg", sep = "")
  ggsave(FileName1 , p3_1, width = 12, height = 11)
  
  FileName <- paste(betapath,"/a2_",method,"bray_label.pdf", sep = "")
  ggsave(FileName, p3_2, width = 12, height = 12)
  FileName1 <- paste(betapath,"/a2_",method,"bray_label.jpg", sep = "")
  ggsave(FileName1 , p3_2, width = 12, height = 11)
  
  # 提取出图数据
  plotdata = result[[2]]
  FileName <-  paste(betapath,"/a2_",method,"bray.csv", sep = "")
  write.csv(plotdata,FileName)
  #---------排序-精修图
  plotdata =result[[2]]
  head(plotdata)
  # 求均值
  cent <- aggregate(cbind(x,y) ~Group, data = plotdata, FUN = mean)
  cent
  # 合并到样本坐标数据中
  segs <- merge(plotdata, setNames(cent, c('Group','oNMDS1','oNMDS2')),
                by = 'Group', sort = FALSE)
  
  # p2$layers[[2]] = NULL
  # library(ggcor)
  library(ggsci)
  p3_3 = p3_1 +geom_segment(data = segs,
                            mapping = aes(xend = oNMDS1, yend = oNMDS2,color = Group),show.legend=F) + # spiders
    geom_point(mapping = aes(x = x, y = y),data = cent, size = 5,pch = 24,color = "black",fill = "yellow") +
    scale_fill_manual(values = colset1)+
    scale_color_manual(values = colset1,guide = F) + 
    mytheme1 
  # theme(legend.position = c(0.2,0.2))
  p3_3
  
  FileName <- paste(betapath,"/a2_",method,"bray_star.pdf", sep = "")
  ggsave(FileName, p3_3, width = 8, height = 7)
  FileName1 <- paste(betapath,"/a2_",method,"bray_star.jpg", sep = "")
  ggsave(FileName1 , p3_3, width = 8, height = 7)
  
}

map

#提取总体比较
TResult =result[[5]]
head(TResult)

# 提取两两检测结果
pair = result[[4]]
pair
FileName <- paste(betapath,"Pair_anosim.csv", sep = "")
write.csv(pair,FileName)
FileName <- paste(betapath,"Total_anosim.csv", sep = "")
write.csv(TResult,FileName)

#--换用adonis差异分析
title1 = MicroTest(ps = ps, Micromet = "adonis", dist = "bray")
title1
FileName <- paste(betapath,"Total_adonis.csv", sep = "")
write.csv(title1,FileName)
# pairResult = pairMicroTest(ps = ps, Micromet = "adonis")
# FileName <- paste(betapath,"Pair_anosim.csv", sep = "")
# write.csv(pair,FileName)

#-- flower plot#-----
flowpath = paste(otupath,"/flowplot/",sep = "")
dir.create(flowpath)


source("E:\\Shared_Folder\\Function_local\\R_function\\micro/ggflowerplot.R")
p0_1 <- ggflower(ps = ps ,
                 # rep = 1,
                 group = "ID",
                 start = 1, # 风车效果
                 m1 = 1, # 花瓣形状，方形到圆形到棱形，数值逐渐减少。
                 a = 0.2, # 花瓣胖瘦
                 b = 1, # 花瓣距离花心的距离
                 lab.leaf = 1, # 花瓣标签到圆心的距离
                 col.cir = "yellow",
                 N = 0.5
) 

p0_1 

# p + scale_fill_brewer(palette = "Paired")
FileName1 <- paste(flowpath,"ggflowerID.pdf", sep = "")
ggsave(FileName1, p0_1, width = 8, height = 8)
FileName2 <- paste(flowpath,"ggflowerID.jpg", sep = "")
ggsave(FileName2, p0_1, width = 8, height = 8 )



p0_2 <- ggflower(ps = ps,
                 # rep = 1,
                 group = "Group",
                 start = 1, # 风车效果
                 m1 = 1.8, # 花瓣形状，方形到圆形到棱形，数值逐渐减少
                 a = 0.3, # 花瓣胖瘦
                 b = 1, # 花瓣距离花心的距离
                 lab.leaf = 1, # 花瓣标签到圆心的距离
                 col.cir = "yellow",
                 N = 0.1
) + scale_fill_manual(values = colset1) 
p0_2

FileName1 <- paste(flowpath,"ggflowerGroup.pdf", sep = "")
ggsave(FileName1, p0_2, width = 14, height = 14)
FileName2 <- paste(flowpath,"ggflowerGroup.jpg", sep = "")
ggsave(FileName2, p0_2, width = 14, height = 14 )


# ggplot升级版本韦恩图和Upset#-------

source("E:\\Shared_Folder\\Function_local\\R_function\\micro/Ven.Upset.gg.R")

if (gnum < 6) {
  Venpath = paste(otupath,"/Ven_Upset_super/",sep = "")
  dir.create(Venpath)
  
  library(ggVennDiagram)
  res = Ven.Upset(ps =  ps,
                  group = "Group",
                  N = 0.5,
                  size = 3)
  
  p1 = res[[1]]
  p2 = res[[2]]
  
  filename3 <- paste(Venpath,"Ven_gg.pdf", sep = "")
  ggsave(filename3, p1, width = 8, height = 8)
  filename3 <- paste(Venpath,"Upset_gg.pdf", sep = "")
  ggsave(filename3, p2, width = 8, height = 8)
}



#-----差异代谢物#----------
source("E:\\Shared_Folder\\Function_local\\R_function\\GC-MS\\wlxSuper_GCMS.R")
alppath = paste(otupath,"/All_different_CNPS/",sep = "")
dir.create(alppath)

#--非参数检验
result = statSuper(ps = ps,group  = "Group",artGroup = NULL,method = "wilcox")
head(result)
FileName <- paste(alppath,"/data_wlx_all.compounds.csv", sep = "")
write.csv(result,FileName,sep = "")
#--t检验检验--建议四个重复以上
result = statSuper(ps = ps,group  = "Group",artGroup = NULL,method = "ttext")
head(result)
FileName <- paste(alppath,"/data_ttest_all.compounds.csv", sep = "")
write.csv(result,FileName,sep = "")


#--随机森林#---------

matpath = paste(otupath,"/Machine_learing/",sep = "")
rank.names(ps)

pst = ps %>% subset_samples.wt("Group",c("Group1","Group2"))
map = pst %>% sample_data()
dir.create(matpath )


source("E:\\Shared_Folder\\Function_local\\R_function\\micro\\MicroMachine_learning.R")

library(randomForest)
library(caret)
library(ROCR) ##用于计算ROC
library(e1071)
mapping = as.data.frame(phyloseq::sample_data(ps))



#--随机森林全套-如果圈图尚未显示前面几个，就设定max大一点
head(tax)
rank.names(ps)
optimal = 40
result = MicroRF(ps = pst,
                 group  = "Group",
                 optimal = 50,
                 rfcv = F,
                 nrfcvnum = 5,
                 min = -1,max = 10,
                 fill = "Group",
                 lab = "symbol"
)
#火柴图展示前二十个重要的OTU
p <- result[[1]] + 
  mytheme1
p

filename = paste(matpath,"/randonforest_loading.pdf",sep = "")
ggsave(filename,p,width = 16,height = optimal/2)
filename = paste(matpath,"/randonforest_loading.jpg",sep = "")
ggsave(filename,p,width = 16,height = optimal/2)

# 圈图展示
p <- result[[2]]
p
filename = paste(matpath,"/randonforest_loading_circle.pdf",sep = "")
ggsave(filename,p,width = 8,height = 10)
filename = paste(matpath,"/randonforest_loading_circle.jpg",sep = "")
ggsave(filename,p,width = 8,height = 10)

p <- result[[6]]
p
filename = paste(matpath,"/Show_model.pdf",sep = "")
ggsave(filename,p,width = 8,height = 4)
filename = paste(matpath,"/Show_model.jpg",sep = "")
ggsave(filename,p,width = 8,height = 4)


data <- result[[5]]
filename = paste(matpath,"/randomforest_data.csv",sep = "")
write.csv(data,filename,quote = F)

head(data)
#  分组展示#-----

library("phyloseq")
library(tidyverse)

mapping = as.data.frame(sample_data(ps))
head(mapping)
mapping$ID = row.names(mapping) 
sample_data(ps) = mapping



head(data)

ps1 <- pst %>%
  subset_taxa(
    row.names(tax_table(pst)) %in% data$row.id
  )
ps1


otu_table = as.data.frame(t(vegan_otu(ps1)))
head(otu_table)

design = as.data.frame(sample_data(ps1))
## 计算相对丰度，计算每个物种丰度均值，按照均值排序
OTU = as.matrix(otu_table)
norm = t(t(OTU)/colSums(OTU,na=TRUE)) #* 100 # normalization to total 100
norma = norm %>% 
  t() %>% as.data.frame()
#数据分组计算平均值
iris.split <- split(norma,as.factor(design$Group))

iris.apply <- lapply(iris.split,function(x)colMeans(x,na.rm = TRUE))
# 组合结果
norm2 <- do.call(rbind,iris.apply)%>% 
  t() 
norm2 = as.data.frame(norm2)
norm2$mean=apply(norm2,1,mean)
norm2$ID = row.names(norm2)
colnames(norm2)
##按照mean、列进行排序desc设置从大到小排序
norm3<- arrange(norm2, desc(mean))
row.names(norm3) = norm3$ID
norm3$ID = NULL
### 提取前30个属
wt = norm3
wt$mean = NULL

### 添加OTU注释信息

tax_table = as.data.frame(vegan_tax(ps1))
head(tax_table)
wt_tax = merge(wt,tax_table,by = "row.names",all = F)
head(wt_tax)
row.names(wt_tax) = wt_tax$Row.names

res = wt_tax

res$ID = row.names(wt_tax)



wt = res[,c(colnames(wt))]
head(wt)
wt = wt[match(row.names(data),row.names(wt)),]


color = colorRampPalette(c("navy", "white", "firebrick3"))(60)

wt2<-sqrt(wt)
wt2[wt2>0.5]<-0.5
wt2<-sqrt(wt2)


library(pheatmap)
p = pheatmap(wt2,fontsize=6,cellwidth = 12, cellheight =6,cluster_rows = FALSE,cluster_cols = FALSE,
             color = colorRampPalette(c("navy", "white", "firebrick3"))(60),
             display_numbers = FALSE,labels_row  = row.names(data))


p

FileName2 <- paste(matpath,"/","mean_laading",".pdf", sep = "")
ggsave(FileName2, p, width = 6, height =12)
# ggsave(FileName2, p, width = 6, height =12, device = cairo_pdf, family = "Times New Roman" )



#--按照样本展示#-------
head(data)

mapping = as.data.frame(sample_data(pst))
head(mapping)
mapping$ID = row.names(mapping) 
sample_data(ps) = mapping





ps1 <- pst %>%
  subset_taxa(
    row.names(tax_table(ps)) %in%  data$row.id
  )
ps1

otu_table = as.data.frame(t(vegan_otu(ps1)))
head(otu_table)

design = as.data.frame(sample_data(ps1))
## 计算相对丰度，计算每个物种丰度均值，按照均值排序
OTU = as.matrix(otu_table)
norm = t(t(OTU)/colSums(OTU,na=TRUE)) #* 100 # normalization to total 100
norma = norm %>% 
  as.data.frame()
head(norma)
### 提取前30个属
wt = norma


### 添加OTU注释信息

tax_table = as.data.frame(vegan_tax(ps1))
head(tax_table)
wt_tax = merge(wt,tax_table,by = "row.names",all = F)
head(wt_tax)
row.names(wt_tax) = wt_tax$Row.names

res = wt_tax

res$ID = row.names(wt_tax)



wt = res[,c(colnames(wt))]
head(wt)
head(data)

wt = wt[match(row.names(data),row.names(wt)),]

color = colorRampPalette(c("navy", "white", "firebrick3"))(60)

wt2<-sqrt(wt)
wt2[wt2>0.5]<-0.5
wt2<-sqrt(wt2)
head(wt)


library(pheatmap)
p = pheatmap(wt2,fontsize=6,cellwidth = 12, 
             cellheight =6,cluster_rows = FALSE,
             cluster_cols = FALSE,
             color = colorRampPalette(c("navy", "white", "firebrick3"))(60),
             display_numbers = FALSE,
             labels_row  = row.names(wt),labels_col  = colnames(wt))


p

FileName2 <- paste(matpath,"/","Sample_laading",".pdf", sep = "")
ggsave(FileName2, p, width = 15, height =12)
#ggsave(FileName2, p, width = 6, height =12, device = cairo_pdf, family = "Times New Roman" )
#---相对丰度标准化展示#------
head(data)
ps1 <- pst %>%
  subset_taxa(
    row.names(tax_table(pst)) %in% data$row.id
  )
ps1



otu_table = as.data.frame(t(vegan_otu(ps1)))
head(otu_table)

design = as.data.frame(sample_data(ps1))
## 计算相对丰度，计算每个物种丰度均值，按照均值排序
OTU = as.matrix(otu_table)
norm = t(t(OTU)/colSums(OTU,na=TRUE)) #* 100 # normalization to total 100
norma = norm %>% 
  t() %>% as.data.frame()
#数据分组计算平均值
iris.split <- split(norma,as.factor(design$Group))

iris.apply <- lapply(iris.split,function(x)colMeans(x,na.rm = TRUE))
# 组合结果
norm2 <- do.call(rbind,iris.apply)%>% 
  t() 
norm2 = as.data.frame(norm2)
norm2$mean=apply(norm2,1,mean)
norm2$ID = row.names(norm2)
colnames(norm2)
abun = norm2
head(abun)
abun$mean = NULL
abun_a = melt(abun,
              id.var = c("ID"),
              variable.name = "id", 
              value.name = "count")

head(abun_a)
abun_a$iid = rep(paste(1:(length(abun_a$id)/2)),2)

library(plyr)
abun_a1 = ddply(abun_a,"iid",transform,percount = count/sum(count)*100)
head(abun_a1)
mi = c( "firebrick3","navy")

head(abun_a1)
abun_a1$ID = factor(abun_a1$ID,levels =data$row.id)
p = abun_a1  %>%
  ggplot(aes(x = ID, y = percount, fill =id, group =id)) +
  geom_bar(stat = 'identity') + scale_fill_manual(values = mi)+
  # theme_classic()+
  theme_classic()+
  theme(axis.text.x=element_text(angle=90,vjust=0.5, hjust=1,size = 4)) 
p

plotname <- paste(matpath,"/a4_random_forst_loaing_abun",optimal,".pdf",sep = "")

ggsave(plotname, p, width = 15, height = 6)






# 机器学习特征网络分析--待更新#-----
head(data)
library(igraph)
library(network)
library(sna)
matpath = paste(otupath,"/Machine_learing/",sep = "")
dir.create(matpath )

ps
map= sample_data(ps)
ids = map$Group %>% unique()


for (group in ids) {
  pst = ps %>% subset_samples.wt("Group",group) %>%
    subset_taxa.wt("OTU",data$id)
  
  
  #----------计算相关
  result = cor_Big_micro2 (ps = pst,
                           N = 0,
                           met.scale = "TMM",
                           r.threshold=0.6,
                           p.threshold=0.05,
                           method = "spearman"
  )
  #--提取相关矩阵
  cor = result[[1]]

  
  
  #-网络中包含的OTU的phyloseq文件提取
  ps_net = pst %>% subset_taxa.wt("OTU",colnames(cor))
  otu = ps_net %>% 
    vegan_otu() %>%
    t() %>%
    as.data.frame() %>% rowSums() %>% as.data.frame() %>%rownames_to_column("elements")
  
  netClu  = modulGroup( cor = cor,cut = NULL,method = "cluster_fast_greedy" )
  head(netClu)
  result2 = model_maptree_group(cor = cor,
                                nodeGroup = netClu,
  )
  node = result2[[1]]
  head(node)
  
  #-----计算边
  edge = edgeBuild(cor = cor,node = node) %>% as.data.frame()
  head(edge)
  head(node)
  
  nod = data.frame(row.names = node$elements,v.name = node$elements,ID =  node$elements)
  head(nod)
  
  colnames(otu)[2] = "MeanAbundance"
  nod = nod %>% left_join(otu,by = c("v.name" = "elements"))
  
  # Add label angle
  number_of_bar<-nrow(nod)
  nod$id = seq(1, nrow(nod))
  angle= 360 * (nod$id-0.5) /number_of_bar     # I substract 0.5 because the letter must have the angle of the center of the bars. Not extreme right(1) or extreme left (0)
  nod$hjust<-ifelse(angle>180, 1.05, -0.05)
  nod$angle<-ifelse(angle>180, 90-angle+180, 90-angle)
  
  mygraph <- graph_from_data_frame( data.frame(from = edge$OTU_2,to = edge$OTU_1,wei_label = edge$cor), 
                                    vertices = nod, 
                                    directed = FALSE )
  
  # Find community
  com <- walktrap.community(mygraph)
  # mycolor = c("#377EB8","#E41A1C" )
  tem = edge$cor %>% unique() %>% length()
  if (tem == 1) {
    mycolor = c("#E41A1C" )
    
  } else if(tem == 2){
    mycolor = c("#377EB8","#E41A1C" )
  }
  
  igraph = make_igraph(cor )
  net.pro = net_properties(igraph)
  filename = paste(matpath,"/",group,"network.proterties.csv",sep = "")
  write.csv(net.pro,filename,quote = F)
  
  
  
  #(b)曲线链接
  library(ggraph)
  p = ggraph(mygraph,layout = 'linear', circular = TRUE) +
    geom_edge_arc(aes(edge_colour=as.factor(wei_label)), edge_alpha=0.5, edge_width=0.3) +
    geom_node_point( aes(size = MeanAbundance),shape=21,color='black',alpha=0.9,fill = "#FF7F00") +
    scale_size_continuous(range=c(0.5,10)) +
    scale_fill_manual(values=mycolor ) +
    geom_node_text(aes(x = x*1.06, y=y*1.06, label=ID, angle=angle,hjust=hjust),size=5,color = "black") +
    scale_color_manual(values=mycolor) +
    scale_edge_color_manual(values=mycolor) +
    expand_limits(x = c(-1.6, 1.6), y = c(-1.6, 1.6))+
    coord_fixed()+
    theme_minimal() +
    theme(
      legend.position="none",
      panel.grid = element_blank(),
      axis.line = element_blank(),
      axis.ticks =element_blank(),
      axis.text =element_blank(),
      axis.title = element_blank(),
      plot.margin=unit(c(0,0,0,0), "null"),
      panel.spacing=unit(c(0,0,0,0), "null")
    ) 
  
  p
  
  
  filename = paste(matpath,"/",group,"special.network.HIGH.pdf",sep = "")
  ggsave(filename,p,width = 8,height = 7)
  filename = paste(matpath,"/",group,"special.network.HIGH.jpg",sep = "")
  ggsave(filename,p,width = 8,height = 7)
  
  filename = paste(matpath,"/",group,"special.network.data.node.High.csv",sep = "")
  write.csv(nod,filename,quote = F)
  
  filename = paste(matpath,"/",group,"special.network.data.edge.High.csv",sep = "")
  write.csv(edge,filename,quote = F)
  
}



