
#----FAPROTAX#---
Bca = TRUE

if (Bca ==T ) {
  # 加载R包
  library(microeco)
  # 加载ggplot2绘图包并设置样式
  library(ggplot2)
  library("WGCNA")
  library(tidyverse)
  library(ggtree)
  library("SpiecEasi")
  library(ggClusterNet)
  library(phyloseq)
  library(magrittr)
  p_list = c("ggplot2", "BiocManager", "devtools","picante", "GUniFrac", 
             "ggalluvial", "rgexf")
  # for(p in p_list){if (!requireNamespace(p)){install.packages(p)}
  #   library(p, character.only = T, quietly = T, warn.conflicts = F)}
  
  # ps = readRDS("./data/dataNEW/ps_16s.rds")
  
  
  
  otu = ps %>% vegan_otu() %>%
    t() %>%
    as.data.frame()
  
  tax = ps %>% vegan_tax() %>%
    as.data.frame()
  # 构建分析对象
  dataset = microtable$new(sample_table = sample_data(ps), otu_table = otu, tax_table = tax)
  
  t2 = trans_func$new(dataset)
  t2$cal_spe_func()
  t2$res_spe_func[1:5, 1:6]
  
  data = t2$res_spe_func
  
  data = data[rowSums(data)> 0,]
  # otupath  = "./FAPROTAX/"
  betapath = paste(otupath,"/FAPROTAX/",sep = "")
  fs::dir_create(betapath)
  
  
  # dir.create("./result_and_plot/Base_diversity_16s//OTU_220921//FAPROTAX")
  
  write.csv(data,paste(betapath,"/FAPROTAX.csv",sep = ""))
  # 查看功能 分组列表
  t2$func_group_list
  # 查看某一类
  t2$show_prok_func("methanotrophy")
  
}

head(data)
# --单个种类微生物展示#--------
#  元素循环注释结果判断这个微生物是否有这个能力，而不能判断能力强弱


source("E:\\Shared_Folder\\Function_local\\R_function\\micro/barMainplot.R")
barpath = paste(betapath,"/FAPROTAX.plot/",sep = "")
dir.create(barpath)


ids = colnames(data)
for (i in 1:length(ids)) {
  id = ids[i]
  dat2  = data %>% select(id) %>% rownames_to_column("ID") %>%
    filter(!!sym(id) > 0)
  head(dat2)
  j = "Genus"
  if (dim(dat2)[1] != 0) {
    
    pst =ps %>% 
      scale_micro() %>%
      subset_taxa.wt("OTU",dat2$ID) 
    pst
    phyloseq::rank_names(ps)
    
    result = barMainplot(ps = pst,
                         j = "Genus",
                         # axis_ord = axis_order,
                         label = FALSE,
                         sd = FALSE,
                         tran = F,
                         Top = 12)
    p4_1 <- result[[1]] + 
      # scale_fill_brewer(palette = "Paired") + 
      scale_fill_manual(values = colset2) +
      scale_x_discrete(limits = axis_order) +
      labs(title = id)+
      mytheme1
    p4_1
    
    p4_2  <- result[[3]] + 
      # scale_fill_brewer(palette = "Paired") + 
      scale_fill_manual(values = colset2) +
      scale_x_discrete(limits = axis_order) + 
      labs(title = id)+
      mytheme1
    p4_2
    
    databar <- result[[2]] %>% group_by(Group,aa) %>%
      summarise(sum(Abundance)) %>% as.data.frame()
    head(databar)
    colnames(databar) = c("Group",j,"Abundance(%)")
    
    
    FileName1 <- paste(barpath,"/a2_",id,"_barflow",".pdf", sep = "")
    ggsave(FileName1, p4_2, width = (5+ gnum), height =8,limitsize = FALSE)
    FileName2 <- paste(barpath,"/a2_",id,"_barflow",".jpg", sep = "")
    ggsave(FileName2, p4_2, width = (5+ gnum), height =8,limitsize = FALSE)
    
    FileName1 <- paste(barpath,"/a2_",id,"_bar",".pdf", sep = "")
    ggsave(FileName1, p4_1, width = (5+ gnum), height =8 ,limitsize = FALSE)
    FileName2 <- paste(barpath,"/a2_",id,"_bar",".jpg", sep = "")
    ggsave(FileName2, p4_1, width = (5+ gnum), height =8,limitsize = FALSE)
    
    FileName <- paste(barpath,"/a2_",j,"_bar_data",".csv", sep = "")
    write.csv(databar,FileName,quote = F)
  }
  
}










# --附件#-----

# head(data)
# 
# dat3 = data.frame(ID = colnames(data),class = 'Function')
# head(dat3)
# 
# 
# dat4 = t2$func_group_list %>% unlist() %>% as.data.frame()
# head(dat4)
# 
# A = c()
# 
# for (i in 1:length(dat3$ID)) {
#   A[i] = (t2$show_prok_func(dat3$ID[i]))
# }
# dat3$class = A
# 
# FileName <- paste(barpath,"/class_data",".csv", sep = "")
# write_csv(dat3,FileName)
# 
# i = 1
# AA = c()
# BB = c()
# ids = colnames(data)
# for (i in 1:length(ids)) {
#   id = ids[i]
#   dat2  = data %>% select(id) %>% rownames_to_column("ID") %>%
#     filter(!!sym(id) > 0)
#   head(dat2)
#   
#   if (dim(dat2)[1] != 0) {
#     
#     pst =ps %>% 
#       scale_micro() %>%
#       subset_taxa.wt("OTU",dat2$ID) 
#     pst
#     
#     otu_table = as.data.frame(t(vegan_otu(pst)))
#     head(otu_table)
#     
#     design = as.data.frame(sample_data(pst))
#     ## 计算相对丰度，计算每个物种丰度均值，按照均值排序
#     norm = as.matrix(otu_table)
#     # norm = t(t(OTU)/colSums(OTU,na=TRUE)) #* 100 # normalization to total 100
#     norma = norm %>% 
#       t() %>% as.data.frame()
#     #数据分组计算平均值
#     iris.split <- split(norma,as.factor(design$Group))
#     
#     iris.apply <- lapply(iris.split,function(x)colMeans(x,na.rm = TRUE))
#     # 组合结果
#     norm2 <- do.call(rbind,iris.apply)%>% 
#       t() 
#     norm2 = as.data.frame(norm2)
#     norm2$mean=apply(norm2,1,mean)
#     norm2$ID = row.names(norm2)
#     head(norm2)
#     tem = norm2[,1:2]
#     tem2=  colSums(tem)
#     AA [i] = tem2[1]
#     BB[i] = tem2[2]
#     
#   }else{
#     AA [i] = 0
#     BB[i] = 0
#   }
# }
# 
# 
# dat3$CK = AA
# dat3$SD = BB
# FileName <- paste(barpath,"/class_data.abundance",".csv", sep = "")
# write_csv(dat3,FileName)
