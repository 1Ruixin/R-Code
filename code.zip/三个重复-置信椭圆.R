
library(vegan)
library(tidyverse)
library(ellipse)
library(ggClusterNet)
library(phyloseq)

ps =  ps %>% 
  subset_samples.wt("ID",c("OE1","OE2","OE3","WT1","WT2","WT3","KO1","KO2","KO3"))
                    
otu = ps %>%
  vegan_otu() %>% t() %>%
  as.data.frame()
map = sample_data(ps) 
head(map)
map$Group =  map$group

bray_curtis =vegan:: vegdist(t(otu),method = "bray", na.rm=TRUE)
pcoa <- otu %>% 
  t() %>%
  vegan:: vegdist(method = "bray", na.rm=TRUE) %>%
  cmdscale(k=2, eig=T) 

points <- pcoa$points %>% as.data.frame() %>%
  # as.tibble() %>%
  dplyr::rename(.,x = "V1",y = "V2" )
head(points) 

eig = pcoa$eig
eig
points = cbind(points, map[match(rownames(points), map$ID), ])
ado = adonis(bray_curtis~ map$Group,permutations = 999,method="bray")
a = round(as.data.frame(ado$aov.tab[5])[1,1],3)
R2 <- paste("adonis:R ",a, sep = "")
b = as.data.frame(ado$aov.tab[6])[1,1]
p_v = paste("p: ",b, sep = "")
title = paste(R2," ",p_v, sep = "")
title


level = 0.95
head(points)
centroids <- aggregate(cbind(x,y)~ Group,points,mean)
head(centroids)
row.names(centroids) = centroids$Group

conf.rgn  <- do.call(rbind,lapply(unique(points$Group),function(t)
  data.frame(Group=as.character(t),
             ellipse::ellipse(cov(points[points$Group==t,1:2]),
                              centre=as.matrix(centroids[t,2:3]),
                              level=level),
             stringsAsFactors=FALSE)))




p4 <- ggplot(points, aes(x=x, y=y)) +
  geom_point(aes(color = p, fill = p, shape = type), alpha=.7, size=5) +
  labs(x=paste("PCoA 1 (", format(100 * eig[1] / sum(eig), digits=4), "%)", sep=""),
       y=paste("PCoA 2 (", format(100 * eig[2] / sum(eig), digits=4), "%)", sep=""),
       title=title) +
  geom_path(data=conf.rgn,linetype = 2,aes(color = Group)) +
  theme_classic()
p4





level = 0.7
head(points)
centroids <- aggregate(cbind(x,y)~ Group,points,mean)
head(centroids)
row.names(centroids) = centroids$Group

conf.rgn  <- do.call(rbind,lapply(unique(points$Group),function(t)
  data.frame(Group=as.character(t),
             ellipse::ellipse(cov(points[points$Group==t,1:2]),
                              centre=as.matrix(centroids[t,2:3]),
                              level=level),
             stringsAsFactors=FALSE)))

p4 <- ggplot(points, aes(x=x, y=y)) +
  geom_point(aes(color = p, fill = p, shape = type), alpha=.7, size=5)  +
  labs(x=paste("PCoA 1 (", format(100 * eig[1] / sum(eig), digits=4), "%)", sep=""),
       y=paste("PCoA 2 (", format(100 * eig[2] / sum(eig), digits=4), "%)", sep=""),
       title=title) +
 #  geom_path(data=conf.rgn,linetype = 2,aes(color = Group)) +
  theme_classic()+

  mytheme1 +
  ggplot2::guides(fill = guide_legend(title = NULL)) +
  ggplot2::scale_fill_manual(values = colset1)+
  ggplot2::scale_color_manual(values = colset1)

p4

ggsave("./3.pdf", p4, width = 8, height = 8)

FileName <- paste(betapath,"/a2_",method,"bray_star.pdf", sep = "")
ggsave(FileName, p4, width = 8, height = 8)

map
