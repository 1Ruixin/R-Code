[TOC]

#!/bin/bash
    # 作者 Authors:  Tao Wen, Yong-Xin Liu, Tong Chen, Xin Zhou, Liang Chen, ...
    # 版本 Version: 分支版本
    # 更新 Update: 

    # 设置软件/数据库(database,db)和工作目录(work directory,wd)并进入wd
    # **每次打开Rstudio必须运行下面3行**
    db=/c/public
    #--工作路径
    # wd=/c/test
    # 
    PATH=$PATH:${db}/win
    cd ${wd}


# 22、扩增子分析流程 16S Amplicon pipeline

    # 系统要求 System requirement: Windows 10 
    # 依赖软件和数据 Sofware and database dependencies: 复制public目录到C盘
    # gitforwidnows 2.23.0 http://gitforwindows.org/(Windows only)
    # R 4.10 https://www.r-project.org/
    # Rstudio 1.4 https://www.rstudio.com/products/rstudio/download/#download
    # vsearch v2.14 https://github.com/torognes/vsearch/releases
    # usearch v10 https://www.drive5.com/usearch/download.html

    # 运行前准备
    # 1. 将amplicon和public目录复制到C盘(C:/)
    
    
    # 关闭 自动翻译软件


## 1. 了解工作目录和起始文件

    #1. 原始测序数据保存于seq目录，通常以`.fq.gz`结尾，每个样品一对文件
    mkdir -p seq # 没有这个目录去除#好，号，建立使用

    # mv *.fq.gz seq
    ls -lsh seq
    
    #2. 样本信息，即实s验设计 metadata.tsv，保存在最终结果result目录
    mkdir -p result
    #3. 分析流程pipeline.sh，每个项目复制一份，再进行个性化修改
    #4. 创建临时文件存储目录，分析结束可删除
    mkdir -p temp

### 1.1. metadata.tsv 实验设计文件

    #cat查看前3行，-A显示符号
    cat -A ./map_16s.tsv | head -n3
    

    #windows用户如果结尾有^M，运行sed命令去除，并cat -A检查结果
    sed -i 's/\r/\n/' ./map_16s.tsv
    # cat -A result/metadata.tsv | head -n3

### 1.2. seq/*.fq.gz 原始测序数据
    #如果是压缩文件，运行下面代码解压缩
    time gunzip seq/*.gz
    # less按页查看，空格翻页、q退出；head查看前10行，-n指定行
    ls seq/
    # cut -c 1-60 seq/KO1_1.fq | head -n4

### 1.3. pipeline.sh 流程依赖数据库

## 2. 合并双端序列并按样品重命名 Merge paired reads and label samples

    #依照实验设计批处理并合并
    #tail -n+2去表头，cut -f 1取第一列，即获得样本列表；18个5万对序列样本合并2m
    #因为系统复制Ctrl+C为Linux下中止命令，防止长时间运行异常中断，结尾添加&转后台

    # tail -n+2 ./metadata.tsv
    # tail -n+2 ./metadata.tsv | cut -f 1
    # for i in `tail -n+2 result/metadata.tsv | cut -f 1`;do echo ${i}; done

    time for i in `tail -n+2 ./map_16s.tsv | cut -f 1`;do
      ${db}/win/vsearch --fastq_mergepairs seq/${i}.R1.fastq --reverse seq/${i}.R2.fastq \
      --fastqout temp/${i}.merged.fq --relabel ${i}.
    done &
    
    # & 代表转后台，防止程序被中断，Terminal右上角有小红点，代表正在运行

    #合并所有样品至同一文件
    cat temp/*.merged.fq > temp/all.fq
    #查看文件大小
    ls -lsh temp/all.fq
    #查看序列名.之前是否为样本名，样本名绝不允许有.
    head -n 6 temp/all.fq|cut -c1-60


## 3. 切除引物与质控 错误率控制0.01即小于1%
    time ${db}/win/vsearch --fastx_filter temp/all.fq \
      --fastq_stripleft 29 --fastq_stripright 18 \
      --fastq_maxee_rate 0.01 \
      --fastaout temp/filtered.fa

    # 查看文件前2行，了解fa文件格式
    head -n 2 temp/filtered.fa


## 4. 去冗余挑选OTU/ASV Dereplicate and cluster/denoise
### 4.1 序列去冗余 Dereplication

    # 并添加miniuniqusize最小为10或1/1M，去除低丰度噪音并增加计算速度
    # -sizeout输出丰度, --relabel必须加序列前缀，否则文件头不正常, 10s
    time ${db}/win/vsearch --derep_fulllength temp/filtered.fa \
      --output temp/uniques.fa --relabel Uni --minuniquesize 10 --sizeout
    #高丰度非冗余序列非常小(<2Mb),名称后有size和频率
    ls -lsh temp/uniques.fa
    head -n 2 temp/uniques.fa

### 4.2 聚类OTU/去噪ASV Cluster OTUs / denoise ASV

    #有两种方法：推荐unoise3去噪获得单碱基精度ASV，传统的97%聚类OTU (属水平精度)供备选
    #usearch两种特征挑选方法均自带de novo去嵌合体
    #方法1. 97%聚类OTU，适合大数据/ASV规律不明显/reviewer要求
    #结果耗时6s, 产生878 OTUs, 去除320 chimeras
    # time ${db}/win/usearch -cluster_otus temp/uniques.fa \
    #  -otus temp/otus.fa \
    #  -relabel OTU_

    #方法2. ASV去噪 Denoise: predict biological sequences and filter chimeras
    #59s, 2920 good, 227 chimeras
    time ${db}/win/usearch -unoise3 temp/uniques.fa \
      -zotus temp/zotus.fa
      
    #修改序列名：Zotu为改为ASV方便识别
    sed 's/Zotu/ASV_/g' temp/zotus.fa > temp/otus.fa
    head -n 2 temp/otus.fa
    
    mkdir -p result/raw 
### 4.3 基于参考去嵌合 Reference-based chimera detect   silva_16s_v123.fa rdp_16s_v18.fa
    # vsearch --uchime_ref temp/otus.fa \
    # --db ${db}/usearch/rdp_16s_v18.fa \
    # --nonchimeras result/raw/otus.fa


    cp -f temp/otus.fa result/raw/otus.fa


## 5. 特征表和筛选 Feature table

    # OTU和ASV统称为特征(Feature)，它们的区别是：
    # OTU通常按97%聚类后挑选最高丰度或中心的代表性序列；
    # ASV是基于序列进行去噪(排除或校正错误序列，并挑选丰度较高的可信序列)作为代表性序列

### 5.1 生成特征表 Creat Feature table

    # 方法1. usearch生成特征表，小样本(<30)快；但大样本受限且多线程效率低，84.1%, 4核1m
    # time ${db}/win/usearch -otutab temp/filtered.fa -otus result/raw/otus.fa \
    #   -otutabout result/raw/otutab.txt -threads 4


    # 方法2. vsearch生成特征表 id 0.97
    time ${db}/win/vsearch --usearch_global temp/filtered.fa --db result/raw/otus.fa \
    	--otutabout result/raw/otutab.txt --id 0.97 --threads 6
    #652036 of 761432 (85.63%)可比对，耗时9m
    # windows用户删除换行符^M
    sed -i 's/\r//' result/raw/otutab.txt
    head -n3 result/raw/otutab.txt |cat -A
    
#----构建进化树
    ${db}/win/usearch -cluster_agg result/raw/otus.fa -treeout result/otus.tree

### 5.2 物种注释

    # RDP物种注释(rdp_16s_v16_sp)更快，但缺少完整真核来源数据,可能不完整，耗时15s;
    # SILVA数据库(silva_16s_v123.fa)更好注释真核、质体序列，3h
    time ${db}/win/vsearch --sintax result/raw/otus.fa --db ${db}/usearch/silva_16s_v123.fa \
      --tabbedout result/raw/otus.sintax --sintax_cutoff 0.8
    head result/raw/otus.sintax
    cp result/raw/otu* result/

    #可选统计方法：OTU表简单统计 Summary OTUs table
    ${db}/win/usearch -otutab_stats result/otutab.txt \
      -output result/otutab.stat
    cat result/otutab.stat


## 8. 物种注释结果分类汇总 Taxonomy summary

    # OTU对应物种注释2列格式：去除sintax中置信值，只保留物种注释，替换:为_，删除引号
    

 cut -f 1,4 result/otus.sintax \
      |sed 's/\td/\tk/;s/:/__/g;s/,/;/g;s/"//g;s/\/Chloroplast//' \
      > result/taxonomy2.txt
    head -n3 result/taxonomy2.txt

    #OTU对应物种8列格式：注意注释是非整齐
    #生成物种表格OTU/ASV中空白补齐为Unassigned
     awk 'BEGIN{OFS=FS="\t"}{delete a; a["k"]="Unassigned";a["p"]="Unassigned";a["c"]="Unassigned";a["o"]="Unassigned";a["f"]="Unassigned";a["g"]="Unassigned";a["s"]="Unassigned";\
      split($2,x,";");for(i in x){split(x[i],b,"__");a[b[1]]=b[2];} \
      print $1,a["k"],a["p"],a["c"],a["o"],a["f"],a["g"],a["s"];}' \
      result/taxonomy2.txt > temp/otus.tax
    sed 's/;/\t/g;s/.__//g;' temp/otus.tax|cut -f 1-8 | \
      sed '1 s/^/OTUID\tKingdom\tPhylum\tClass\tOrder\tFamily\tGenus\tSpecies\n/' \
      > result/taxonomy.txt
    head -n3 result/taxonomy.txt
    
 gzip seq/*

    # 分双端统计md5值，用于数据提交
    cd seq
    md5sum *R1.fastq.gz > md5sum1.txt
    md5sum *R2.fastq.gz > md5sum2.txt
    paste md5sum1.txt md5sum2.txt | awk '{print $2"\t"$1"\t"$4"\t"$3}' | sed 's/*//g' > ../result/md5sum.txt
    rm md5sum*
    cd ..
    cat result/md5sum.txt
#------------------------------------------------跑到这里------------------------------------------------------





## 9. 有参比对——功能预测，如Greengene，可用于picurst, bugbase分析

    mkdir -p result/gg/
    #与GG所有97% OTUs比对，用于功能预测

    #方法1. usearch比对更快
    time ${db}/win/usearch -otutab ./temp/filtered.fa -otus ${db}/gg/97_otus.fasta \
    	-otutabout result/gg/otutab.txt -threads 4
    #79.9%, 4核时8m
    head -n3 result/gg/otutab.txt

    # #方法2. vsearch比对，更准但更慢，但并行更强
    # time ${db}/win/vsearch --usearch_global temp/filtered.fa --db ${db}/gg/97_otus.fasta \
    #   --otutabout result/gg/otutab.txt --id 0.97 --threads 12

    #统计
    ${db}/win/usearch -otutab_stats result/gg/otutab.txt -output result/gg/otutab.stat
    cat result/gg/otutab.stat


## 10. 空间清理及数据提交

    #删除中间大文件
    # rm -rf temp/*.fq
    #原始数据及时压缩节省空间并上传数据中心备份, 54s
    gzip seq/*

    # 分双端统计md5值，用于数据提交
    cd seq
    md5sum *_1.fq.gz > md5sum1.txt
    md5sum *_2.fq.gz > md5sum2.txt
    paste md5sum1.txt md5sum2.txt | awk '{print $2"\t"$1"\t"$4"\t"$3}' | sed 's/*//g' > ../result/md5sum.txt
    rm md5sum*
    cd ..
    cat result/md5sum.txt


#---------------------------------------------linux下操作-----------------------

# 以下操作注意R语言版本，使用Qiime1镜像即可
#PICRUSt功能预测#-----------
#转换为OTU表通用格式，方便下游分析和统计
biom convert -i ./result/gg/otutab.txt \
-o ./result/gg/otutab.biom \
--table-type="OTU table" --to-jsony
#校正拷贝数
normalize_by_copy_number.py -i ./result/gg/otutab.biom \
-o ./result/gg/otutab_norm.biom \
-c ~/Desktop/Shared_Folder/Function_local/softweare/picrust/picrust/data/16S_13_5_precalculated.tab.gz
#预测宏基因组KO表，biom方便下游归类，txt方便查看分析
predict_metagenomes.py -i ./result/gg/otutab_norm.biom \
-o ./result/gg/ko.biom \
-c ~/Desktop/Shared_Folder/Function_local/softweare/picrust/picrust/data/ko_13_5_precalculated.tab.gz
predict_metagenomes.py -f -i ./result/gg/otutab_norm.biom \
-o ./result/gg/ko.txt \
-c ~/Desktop/Shared_Folder/Function_local/softweare/picrust/picrust/data/ko_13_5_precalculated.tab.gz

#按功能级别分类汇总, -c输出KEGG_Pathways，分1-3级
sed  -i '/#Constru/d;s/#OTU //' ko.txt
num=`tail -n1 ko.txt|wc -w`
for i in 1 2 3;do
categorize_by_function.py -f -i ./result/gg/ko.biom -c KEGG_Pathways -l ${i} -o ./result/gg/ko${i}.txt
sed  -i '/#Constru/d;s/#OTU //' ./result/gg/ko${i}.txt
done



#----bugbase#------------
#输入文件：基于greengene OTU表的biom格式(本地分析支持txt格式无需转换)和mapping file(metadata.tsv首行添加#)
wget https://github.com/knights-lab/BugBase/archive/master.zip
mv master.zip BugBase.zip
unzip BugBase.zip
mv BugBase-master/ BugBase
    
#安装依赖包
cd BugBase
export BUGBASE_PATH=`pwd`
export PATH=$PATH:`pwd`/bin
#安装了所有依赖包
run.bugbase.r -h

sed '1 s/^/#/' metadata.tsv > MappingFile.txt
run.bugbase.r -i ./result/gg/otutab.txt \
-m MappingFile.txt -c Group -o ./result/bugbase/




#FAPROTAX#-------------
python /home/wentao/Desktop/Shared_Folder/Function_local/softweare/FAPROTAX_1.1/collapse_table.py

#txt转换为biom json格式
biom convert -i ./result/otutab.txt -o ./result/otutab.biom --table-type="OTU table" --to-json
#添加物种注释
biom add-metadata -i ./result/otutab.biom --observation-metadata-fp ./result/taxonomy2.txt \
-o ./result/otutab_tax.biom --sc-separated taxonomy \
--observation-header OTUID,taxonomy

#指定输入文件、物种注释、输出文件、注释列名、属性列名
mkdir ./result/FAPROTAX
python /home/wentao/Desktop/Shared_Folder/Function_local/softweare/FAPROTAX_1.1/collapse_table.py -i ./result/otutab_tax.biom \
-g /home/wentao/Desktop/Shared_Folder/Function_local/softweare/FAPROTAX_1.1/FAPROTAX.txt \
--collapse_by_metadata 'taxonomy' -v --force \
-o ./result/FAPROTAX/faprotax.txt -r ./result/FAPROTAX/faprotax_report.txt



#--Picrust2#-------------


wget https://github.com/picrust/picrust2/archive/v2.3.0-b.tar.gz
tar xvzf  v2.3.0-b.tar.gz
cd picrust2-2.3.0-b/
python setup.py build
python setup.py install
```

# 但是安装起来有一些问题：

# - 数据库链接找不到：在对应位置放一个软连接或者文件复制过去
# - 一些依赖需要安装
# - 如果找不到R包：安装R包
conda install epa-ng hmmer gappa


picrust2_pipeline.py -s ./result/otus.fa  -i ./result/otutab.txt   -o ./result/pi
crust2_out_pipeline  





#-真菌功能预测picrust2--自定义数据库#-----------

# 略


#-真菌功能预测FUNGuide#-----------

#--使用R语言版本 见 OTU_base_diversity 部分 






