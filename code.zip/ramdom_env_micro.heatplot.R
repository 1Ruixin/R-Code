ramdom_env_micro.heatplot=function(
    ps = ps,
    env = env,
    seed = 1
    
   
){
  j=1
  map = phyloseq::sample_data(ps)
  x = unique(map$Group) %>% length()
  for (j in 1:x) {
    pssub = ps
    
    map.1 = map[map$Group == unique(map$Group)[j],]
    phyloseq::sample_data(pssub) = map
    
    dat <- random.cor(pssub = pssub,seed = seed)
    head(dat)
    dat = cbind(dat,facet = unique(map$Group)[j])
    if (j == 1) {
      dat0 = dat
    }
    
    if (j != 1) {
      dat0 = rbind(dat0,dat)
    }
    
  }
  
  head(dat0)
  df = dat0[,c(1,3,5,8)]
  head(df)
  
  pcm = reshape2::melt(df, id = c("id","facet"))
  head(pcm)
  
  df = dat0[,c(5,6,7,8)]
  head(df)
  colnames(df)[c(2,3)] = c("PC1","PC2")
  pcm1 = reshape2::melt(df, id = c("id","facet"))
  head(pcm1)
  colnames(pcm1)[4] = "label"
  
  pcm2 = pcm %>% 
    dplyr::inner_join(pcm1)
  
  
  p = ggplot(pcm2, aes(y = id, x = variable)) + 
    # geom_point(aes(size = value,fill = value), alpha = 0.75, shape = 21) + 
    geom_tile(aes(size = value,fill = value))+
    scale_size_continuous(limits = c(0.000001, 100), range = c(2,25), breaks = c(0.1,0.5,1),guide = F) + 
    geom_text(aes(label = label)) + 
    labs( y= "", x = "", size = "", fill = "")  + 
    # scale_fill_manual(values = colours, guide = FALSE) + 
    scale_x_discrete(limits = rev(levels(pcm$variable)))  + 
    scale_x_discrete(limits = c("PC1","PC2"))  + 
    # scale_y_discrete(position = "right") +
    scale_fill_gradientn(colours =colorRampPalette(c("white","#984EA3"))(60)) +
    theme(
      panel.background=element_blank(),
      panel.grid=element_blank(),
      axis.text.x = element_text(colour = "black",size = 5,angle = 60,vjust = 1,hjust = 1)
    ) +facet_wrap(.~facet,scales="free_y",ncol  = x)
  
  p
  # p <- ggplot(df, aes(x =`%IncMSE` , y =reorder(`rownames(df)`,`%IncMSE`) )) + 
  #   geom_bar(stat = "identity", width = 0.75,position = "dodge",colour="black",fill="#9ACD32",alpha=1) + 
  #   geom_text(aes(label = label),size = 5) + 
  #   labs(y="", x="", title = "",size=9)+
  #   theme_bw() +
  #   theme(axis.text=element_text(colour='black',size=9))
  # p
  return(list(p,pcm2))
  
}
