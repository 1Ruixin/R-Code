
getwd()
dir.create("./seq")
#------构建phyloseq对象-----
# 将mv ./Raw_fastq/*.gz ./seq 每个文件夹内的序列合并到一个文件夹内
 
library(tidyverse)
#前端序列
fl_1 =dir("./seq//", pattern = c(".R1_001.fastq.gz"), full.names = F, ignore.case = TRUE)
fl_1 
tem = paste("A",1: length(fl_1),".R1.fastq.gz",sep = "")
dat1 = data.frame(name = tem, orig = fl_1)



fl_1 =dir("./seq//", pattern = c(".R1_001.fastq.gz"), full.names = T, ignore.case = TRUE)
fl_1 
fl_2 = paste("./seq/",tem,sep = "")
file.rename(fl_1, fl_2) #函数形式为file.rename(from, to)，from为原始文件名向量，to为新的文件名向量

# file.rename(paste("./seq/",dat1$name,sep = ""), paste("./seq/",dat1$orig,sep = ""))

#--后端
fl_1 =dir("./seq//", pattern = c(".R2_001.fastq.gz"), full.names = F, ignore.case = TRUE)
fl_1 
tem = paste("A",1: length(fl_1),".R2.fastq.gz",sep = "")
dat2 = data.frame(name2 = tem, orig2 = fl_1)


fl_1 =dir("./seq//", pattern = c(".R2_001.fastq.gz"), full.names = T, ignore.case = TRUE)
fl_1 
fl_2 = paste("./seq/",tem,sep = "")
file.rename(fl_1, fl_2) #函数形式为file.rename(from, to)，from为原始文件名向量，to为新的文件名向量

# file.rename(paste("./seq/",dat2$name2,sep = ""), paste(dat2$orig2,sep = ""))

map = cbind(dat1,dat2) 
head(map)

map$ID = paste("A",1: length(fl_1),sep = "")
map = map %>% select(ID,everything())
write.table(map, file ="./map_16s.tsv", sep = "\t", row.names = FALSE)



#-----med1#----------
# 从文件读取
metadata = read.delim("./map_16s.tsv")
head(metadata)
metadata$Group = sub(".+//([^_]+).*", "\\1", metadata$orig)
metadata$Group = gsub("-","",metadata$Group)  
metadata$Group = gsub("\\d", "",metadata$Group)

row.names(metadata) = metadata$ID
metadata$SampleID= metadata$ID

otutab = read.table("./result/otutab.txt", header=T, row.names=1, sep="\t", comment.char="", stringsAsFactors = F)
head(otutab)
# colnames(otutab) <- gsub("X","",colnames(otutab))
taxonomy = read.table("./result/taxonomy.txt", header=T, row.names=1, sep="\t", comment.char="", stringsAsFactors = F)
head(taxonomy )

library(ggtree)
tree = read.tree("./result/otus.tree")

library(Biostrings)
rep = readDNAStringSet("result/otus.fa")

# 导入phyloseq(ps)对象
library(phyloseq)

ps = phyloseq(sample_data(metadata),
              otu_table(as.matrix(otutab), taxa_are_rows=TRUE), 
              tax_table(as.matrix(taxonomy)),
              phy_tree(tree),
              refseq(rep)
              )
ps
sample_data(ps)

saveRDS(ps,"./data/ps_16s_soil.rds")

dir.create("data")

#-----med2#----------
# 从文件读取
map = read.delim("./data/分组文件.txt")
head(map)
colnames(map)[1] = "ID"
map$ID = paste("A",map$ID,sep = "")
row.names(map) = map[[1]]
library(readxl)
otutax = read.delim("./data/16s/otu_taxa_table.xls",row.names = 1)
head(otutax)
library(tidyverse)
otu = otutax[,1:length(map$ID)]
colnames(otu) = gsub("^X","",colnames(otu))
colnames(otu) = paste("A",colnames(otu) ,sep = "")

tax = data.frame(tax = otutax$taxonomy,row.names = row.names(otutax))
head(tax)
tax <- tax %>% 
  tidyfst::separate_dt(tax,
                    into = c("Kingdom","Phylum","Class","Order","Family","Genus","Species"),
                    sep = "\\;",
                    remove = F) %>% select(-tax) %>% as.tibble() 

tax = tax %>% as.data.frame()
row.names(tax) = row.names(otutax)
head(tax)
# library(ggtree)
# tree = read.tree("./result/otus.tree")

library(Biostrings)
rep = readDNAStringSet("data/16s/otu_rep.fasta")
names(rep) = sapply(strsplit(names(rep), "[ ]"), `[`, 1)
# 导入phyloseq(ps)对象
library(phyloseq)

ps = phyloseq(
  sample_data(map),
              otu_table(as.matrix(otu), taxa_are_rows=TRUE), 
              tax_table(as.matrix(tax)),
              # phy_tree(tree),
              refseq(rep)
)
ps


saveRDS(ps,"./data/ps_16s.rds")


#-----med2#----------
# 从文件读取
map = read.delim("./data/分组文件.txt")
head(map)
colnames(map)[1] = "ID"
map$ID = paste("A",map$ID,sep = "")
row.names(map) = map[[1]]
library(readxl)
otutax = read.delim("./data/ITS//otu_taxa_table.xls",row.names = 1)
head(otutax)
library(tidyverse)
otu = otutax[,1:length(map$ID)]
colnames(otu) = gsub("^X","",colnames(otu))
colnames(otu) = paste("A",colnames(otu) ,sep = "")

tax = data.frame(tax = otutax$taxonomy,row.names = row.names(otutax))
head(tax)
tax <- tax %>% 
  tidyfst::separate_dt(tax,
                       into = c("Kingdom","Phylum","Class","Order","Family","Genus","Species"),
                       sep = "\\;",
                       remove = F) %>% select(-tax) %>% as.tibble() 

tax = tax %>% as.data.frame()
row.names(tax) = row.names(otutax)
head(tax)
# library(ggtree)
# tree = read.tree("./result/otus.tree")

library(Biostrings)
rep = readDNAStringSet("data/ITS//otu_rep.fasta")
names(rep) = sapply(strsplit(names(rep), "[ ]"), `[`, 1)
# 导入phyloseq(ps)对象
library(phyloseq)

ps = phyloseq(
  sample_data(map),
  otu_table(as.matrix(otu), taxa_are_rows=TRUE), 
  tax_table(as.matrix(tax)),
  # phy_tree(tree),
  refseq(rep)
)
ps


saveRDS(ps,"./data/ps_ITS.rds")


