library(openxlsx)
getwd()

da1 = read.xlsx("./data/工作簿1.xlsx",sheet = 2)
head(da1)
row.names(da1) =  da1$description
da1$KO = NULL
da1$description = NULL

library(pheatmap)
# column
p = pheatmap(da1,  cluster_rows = T,cluster_cols = T,scale = "column")
 
dir.create("./result_and_plot/2.28")

save_pheatmap_pdf <- function(x,filename,width=10, height=8){
  stopifnot(!missing(x))
  stopifnot(!missing(filename))
  pdf(filename,width=width,height=height)
  grid::grid.newpage()
  grid::grid.draw(x$gtable)
  dev.off()
}

barpath = paste("./result_and_plot/2.28","/菌功能/",sep = "")
dir.create(barpath)

FileName1 <- paste(barpath,"热图2.pdf", sep = "")

save_pheatmap_pdf(p,FileName1,width=7, height=5)


# 
#---高丰度微生物和环境因子的关系探索#----
source("G:\\圆桌会议/micro/cor_env_ggcorplot.R")

heatpath = paste("./result_and_plot/2.28","/cor_env_heapmap_boplot/",sep = "")
dir.create(heatpath)
# library(sna)
# library(igraph)

#---提取门水平
jj = 6
tran = TRUE
Top = 20

ps %>% subset_taxa.wt("Genus", "Granulicell")

# Candidatus_Methylacidiphilum, order Acidobacteria_Subgroup_3, genus Mucilaginibacter

# "Segetibacter",
# "Granulicella",
# "Candidatus_Methylacidiphilum",
# "Bryobacter"
# 
map
p.threshold= 0.05

ps_t =  ps %>% subset_samples.wt("group",c("PoY"
                                           #,"PoB"
                                           ,"PoW"
                                           ),F) %>%
        subset_taxa.wt("Genus",
        c(
          # "Subgroup_3"
          "Mucilaginibacter","Candidatus_Methylacidiphilum"
          #"Candidatus_Solibacter"
          )) 


otu_table(ps_t)
jj= 6
# "Order"
  psdata <- ggClusterNet::tax_glom_wt(ps = ps_t,ranks = jj)
  psdata
  
  psdata = psdata %>%
      phyloseq::transform_sample_counts(function(x) {x/sum(x)})

  
  
  otu = phyloseq::otu_table(psdata)
  tax = phyloseq::tax_table(psdata)
  
  
  
  
  
  if (dim(otu)[1] < Top) {
    top10 <- otu[names(sort(rowSums(otu), decreasing = TRUE)[1:dim(otu)[1]]),]
    top10 = t(top10)
  } else {
    top10 <- otu[names(sort(rowSums(otu), decreasing = TRUE)[1:Top]),]
    top10 = t(top10)
  }
  head(top10)
  
  
  
  env1 = envRDA
  env2 = top10
  if (dim(env2)[2] == 1) {
    env2 = env2
  } else {
    env2 <- env2[match(row.names(env1),row.names(env2)),]
  }
  
  env0 <- cbind(env1,env2)
  occor = psych::corr.test(env0,use="pairwise",method=method,adjust="fdr",alpha=.05)
  occor.r = occor$r
  occor.p = occor$p
  
  occor.r[occor.p > p.threshold&abs(occor.r) < r.threshold] = 0
  
  head(env0)
  # data[data > 0.3]<-0.3
  #drop gene column as now in rows
  # 
  # if (col_cluster) {
  #   clust <- hclust(dist(env1 %>% as.matrix()%>% t())) # hclust with distance matrix
  #   ggtree_plot <- ggtree::ggtree(clust)
  # }
  # if (row_cluster) {
  #   v_clust <- hclust(dist(env2 %>% as.matrix() %>% t()))
  #   ggtree_plot_col <- ggtree::ggtree(v_clust) + ggtree::layout_dendrogram()
  # }
  
  
  occor.r = as.data.frame(occor.r)
  
  if (dim(env2)[2] == 1) {
    data <- occor.r[colnames(env1),colnames(env2)]
    data = data.frame(row.names = colnames(env1),data)
    colnames(data) = colnames(env2)
    data$id = row.names(data)
  } else {
    data <- occor.r[colnames(env1),colnames(env2)]
    data$id = row.names(data)
  }
  
  
  head(data)
  
  
  # data1 = data[,-1]
  # 
  # 
   data2 = merge(data, data1 ,by ="id")
  # 
   colnames(data2)[4] = "Subgroup_3"
  
   row.names(data2) = data2$id
   data2$id = NULL
   
  p = pheatmap(data2,  cluster_rows = T,cluster_cols = T, scale = "none")
  
  #p = pheatmap(data[,-ncol(data)],  cluster_rows = T,cluster_cols = T, scale = "none")
  
  #data1 = data
  # barpath = paste(heatpath,"/cor/",sep = "")
  # 
  # dir.create(barpath)
  FileName1 <- paste(heatpath,"cor_poy.pdf", sep = "")
  
  save_pheatmap_pdf(p,FileName1,width=3.5, height=7)
  




