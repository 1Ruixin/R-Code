runRefBlast = function (path_to_otus, path_to_reference_data = "Tax4Fun2_ReferenceData_v2", 
            path_to_temp_folder = "Tax4Fun2_prediction", database_mode = "Ref100NR", 
             use_force = F, num_threads = 1, include_user_data = F, path_to_user_data = "", 
            name_of_user_data = "") 
{
  # blast_bin = "blastn"
  blast_bin = file.path(path_to_reference_data, "blast_bin/bin/blastn.exe")
  res = system(command = paste(blast_bin, "-help"), intern = T)
  
  if (length(res) == 0) {
    blast_bin = file.path(path_to_reference_data, "blast_bin/bin/blastn")
    if (tolower(Sys.info()[["sysname"]]) == "windows")
      blast_bin = file.path(path_to_reference_data, "blast_bin/bin/blastn.exe")
    res = system(command = paste(blast_bin, "-help"), intern = T)
    if (length(res) == 0)
      stop("blastn not found! Consider to use the buildDependencies() command.")
    system(paste("chmod +x", blast_bin))
  }
  
  makeblastdb_bin = file.path(path_to_reference_data, "blast_bin/bin/makeblastdb.exe")
  #makeblastdb_bin = "makeblastdb"
   res = system(command = paste( makeblastdb_bin, "-help"), intern = T)

  # if (length(res) == 0) {
  #   blast_bin = file.path(path_to_reference_data, "blast_bin/bin/makeblastdb")
  #   if (tolower(Sys.info()[["sysname"]]) == "windows") 
  #     blast_bin = file.path(path_to_reference_data, "blast_bin/bin/makeblastdb.exe")
  #   res = system(command = paste(blast_bin, "-help"), intern = T)
  #   if (length(res) == 0) 
  #     stop("blastn not found! Consider to use the buildDependencies() command.")
  #   system(paste("chmod +x", makeblastdb_bin))
  # }

    blastTableReducer = function(path_to_blast_file = "") {
    # if (file.size(path_to_blast_file) == 0) 
    #   stop("Blast file empty!")
    id1 = ""
    file_in = file(description = path_to_blast_file, open = "r")
    file_out = file(description = paste0(path_to_blast_file, 
                                         ".tmp"), open = "w")
    while (TRUE) {
      line = readLines(con = file_in, n = 1)
      if (length(line) == 0) 
        break
      id2 = strsplit(x = line, split = "\t", fixed = T)[[1]][1]
      if (id1 != id2) {
        id1 = id2
        write(x = line, file = file_out, append = T)
      }
    }
    close(file_in)
    close(file_out)
    file.remove(path_to_blast_file)
    file.rename(from = paste0(path_to_blast_file, ".tmp"), 
                to = path_to_blast_file)
  }
  if (!file.exists(path_to_otus)) 
    stop("Otu file not found!")
  if (!dir.exists(path_to_reference_data)) 
    stop("Reference data not found!")
  if (database_mode == "Ref99NR") {
    path_to_ref_db = file.path(path_to_reference_data, "Ref99NR/Ref99NR.fasta")
  }
  else if (database_mode == "Ref100NR") {
    path_to_ref_db = file.path(path_to_reference_data, "Ref100NR/Ref100NR.fasta")
  }
  else {
    stop("Database mode unknown! valid choces are Ref99NR, Ref100NR")
  }
  if (!file.exists(path_to_ref_db)) 
    stop("Reference database not found!")
  if (dir.exists(path_to_temp_folder)) {
    if (use_force) 
      unlink(x = path_to_temp_folder, recursive = T)
    if (!use_force) 
      stop("Temporay folder exist! Use 'use_force = T' to overwrite")
  }
  dir.create(path_to_temp_folder)
  
  
  path_to_log_file = file.path(path_to_temp_folder, "logfile1.txt")
  write(x = "RefBlast", file = path_to_log_file, append = F)
  write(x = database_mode, file = path_to_log_file, append = T)
  write(x = path_to_otus, file = path_to_log_file, append = T)
  if (include_user_data) 
    write(x = "User data will be included", file = path_to_log_file, 
          append = T)
  write(x = date(), file = path_to_log_file, append = T)
  message("Copy and generate database")
  cmd = paste(makeblastdb_bin, "-dbtype nucl -in", path_to_ref_db)
  if (tolower(Sys.info()[["sysname"]]) == "windows") 
    system(cmd, show.output.on.console = F)
  if (tolower(Sys.info()[["sysname"]]) != "windows") 
    system(cmd, ignore.stdout = T, ignore.stderr = T)
  message("Reference blast started")
  cmd = paste(blast_bin, "-db", path_to_ref_db, "-query", path_to_otus, 
              "-evalue 1e-20 -max_target_seqs 1000000 -outfmt 6 -out", 
              file.path(path_to_temp_folder, "ref_blast.txt"), "-num_threads", 
              num_threads)
  if (tolower(Sys.info()[["sysname"]]) == "windows") 
    system(cmd, show.output.on.console = F)
  if (tolower(Sys.info()[["sysname"]]) != "windows") 
    system(cmd, ignore.stdout = T, ignore.stderr = T)
  blastTableReducer(file.path(path_to_temp_folder, "ref_blast.txt"))
  message("Reference blast finished")
  message("Cleanup finished")
  if (include_user_data) {
    message("Copy and generate user database")
    path_to_user_db = file.path(path_to_user_data, name_of_user_data, 
                                "USER.fasta")
    file.copy(from = path_to_user_db, to = file.path(path_to_temp_folder, 
                                                     "user_blast.fasta"))
    cmd = paste(makeblastdb_bin, "-dbtype nucl -in", file.path(path_to_temp_folder, 
                                                               "user_blast.fasta"))
    if (tolower(Sys.info()[["sysname"]]) == "windows") 
      system(cmd, show.output.on.console = F)
    if (tolower(Sys.info()[["sysname"]]) != "windows") 
      system(cmd, ignore.stdout = T, ignore.stderr = T)
    message("User blast started")
    cmd = paste(blast_bin, "-db", file.path(path_to_temp_folder, 
                                            "/user_blast.fasta"), "-query", path_to_otus, "-evalue 1e-20 -max_target_seqs 1000000 -outfmt 6 -out", 
                file.path(path_to_temp_folder, "user_blast.txt"), 
                "-num_threads", num_threads)
    if (tolower(Sys.info()[["sysname"]]) == "windows") 
      system(cmd, show.output.on.console = F)
    if (tolower(Sys.info()[["sysname"]]) != "windows") 
      system(cmd, ignore.stdout = T, ignore.stderr = T)
    blastTableReducer(file.path(path_to_temp_folder, "user_blast.txt"))
    message("User blast finished")
    unlink(file.path(path_to_temp_folder, "user_blast.fasta*"))
    message("Cleanup finished")
  }
}




cor_env_ggcorplot <- function(
    env1 = env1,
    env2 = env2,
    label =  T,
    col_cluster = T,
    row_cluster = T,
    method = "spearman",
    r.threshold=0.6,
    p.threshold=0.05,
    theme.size = 10
    
){
  
  if (dim(env2)[2] == 1) {
    env2 = env2
  } else {
    env2 <- env2[match(row.names(env1),row.names(env2)),]
  }
  
  env0 <- cbind(env1,env2) %>% na.omit()
  occor = psych::corr.test(env0,use="pairwise",method=method,adjust="fdr",alpha=.05)
  occor.r = occor$r
  occor.p = occor$p
  
  occor.r[occor.p > p.threshold&abs(occor.r) < r.threshold] = 0
  
  head(occor)
  # data[data > 0.3]<-0.3
  #drop gene column as now in rows
  
  if (col_cluster) {
    clust <- hclust(dist(env1 %>% as.matrix()%>% t())) # hclust with distance matrix
    ggtree_plot <- ggtree::ggtree(clust)
  }
  if (row_cluster) {
    v_clust <- hclust(dist(env2 %>% as.matrix() %>% t()))
    ggtree_plot_col <- ggtree::ggtree(v_clust) + ggtree::layout_dendrogram()
  }
  
  
  occor.r = as.data.frame(occor.r)
  
  if (dim(env2)[2] == 1) {
    data <- occor.r[colnames(env1),colnames(env2)]
    data = data.frame(row.names = colnames(env1),data)
    colnames(data) = colnames(env2)
    data$id = row.names(data)
  } else {
    data <- occor.r[colnames(env1),colnames(env2)]
    data$id = row.names(data)
  }
  
  
  pcm = reshape2::melt(data, id = c("id"))
  head(pcm)
  occor.p = as.data.frame(occor.p)
  
  # colnames(data)
  #str(data)
  library(pheatmap)
  # dev.new()
  
  p = pheatmap(data[,-ncol(data)], scale = "none")
  
  data
  pcm2 = reshape2::melt(data, id = c("id"))
  head(pcm2)
  colnames(pcm2)[3] = "p"
  
  pcm2$lab = pcm2$p 
  pcm2$lab[pcm2$lab < 0.001] = "**"
  pcm2$lab[pcm2$lab < 0.05] = "*"
  pcm2$lab[pcm2$lab >= 0.05] = ""
  pcm3 = pcm %>% left_join(pcm2)
  
  
  p1 = ggplot(pcm3, aes(y = id, x = variable)) + 
    # geom_point(aes(size = value,fill = value), alpha = 0.75, shape = 21) + 
    geom_tile(aes(size = value,fill = value))+
    scale_size_continuous(limits = c(0.000001, 100), range = c(2,25), breaks = c(0.1,0.5,1)) + 
    geom_text(aes(label = lab)) +
    labs( y= "", x = "", size = "Relative Abundance (%)", fill = "")  + 
    # scale_fill_manual(values = colours, guide = FALSE) + 
    scale_x_discrete(limits = rev(levels(pcm$variable)))  + 
    scale_y_discrete(position = "right") +
    scale_fill_gradientn(colours =colorRampPalette(c("#377EB8","#F7F4F9","#E41A1C"))(60)) +
    theme(
      panel.background=element_blank(),
      panel.grid=element_blank(),
      axis.text.x = element_text(colour = "black",size = theme.size,angle = 60,vjust = 1,hjust = 1)
    )
  
  
  p2 = ggplot(pcm3, aes(y = id, x = variable)) + 
    geom_point(aes(size = value,fill = value), alpha = 0.75, shape = 21) + 
    scale_size_continuous(limits = c(0.000001, 100), range = c(2,25), breaks = c(0.1,0.5,1)) + 
    geom_text(aes(label = lab)) +
    labs( y= "", x = "", size = "Relative Abundance (%)", fill = "")  + 
    # scale_fill_manual(values = colours, guide = FALSE) + 
    scale_x_discrete(limits = rev(levels(pcm$variable)))  + 
    scale_y_discrete(position = "right")  +
    scale_fill_gradientn(colours =colorRampPalette(c("#377EB8","#F7F4F9","#E41A1C"))(60))  +
    theme(
      panel.background=element_blank(),
      panel.grid=element_blank(),
      axis.text.x = element_text(colour = "black",size = theme.size,angle = 60,vjust = 1,hjust = 1)
    )
  
  if (col_cluster) {
    p1 <- p1  %>%
      aplot::insert_left(ggtree_plot, width=.2) 
    p2 <- p2  %>%
      aplot::insert_left(ggtree_plot, width=.2) 
  }
  
  if (label) {
    p1 <- p1  %>%
      aplot::insert_top(ggtree_plot_col, height=.1)
    p2 <- p2  %>%
      aplot::insert_top(ggtree_plot_col, height=.1)
  }
  return(list(p,p1,p2,data))
}

