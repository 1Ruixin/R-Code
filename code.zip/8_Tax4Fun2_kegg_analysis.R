
library(phyloseq)
library(tidyverse)

#--功能预测tax4fun4 准备#------
if (is.null(ps0@refseq)) {
  Tax4Fun2 = FALSE
} else if(!is.null(ps0@refseq)){
  Tax4Fun2 = TRUE
}

ps.t = ps0 %>% ggClusterNet::filter_OTU_ps(1000)
if (Tax4Fun2) {
  dir.create("data")
  otu = ps.t %>% 
    # ggClusterNet::filter_OTU_ps(1000) %>%
    ggClusterNet:: vegan_otu() %>%
    t() %>%
    as.data.frame()
  # write.table(otu,"./data/otu.txt",quote = F,row.names = T,col.names = T,sep = "\t")
  rep = ps.t %>% 
    # ggClusterNet::filter_OTU_ps(1000) %>%
    phyloseq::refseq()
  rep
  # library(Biostrings)
  Biostrings::writeXStringSet(rep,"./data/otu.fa")
  #开头空一格字符保存
  write.table(otu,"\t", "./data/otu.txt",append = F, quote = F, eol = "", row.names = F, col.names = F)
  # 保存统计结果，有waring正常
  write.table(otu, "./data/otu.txt", append = T, quote = F, sep="\t", eol = "\n", na = "NA", dec = ".", row.names = T, col.names = T)     
  
}


#-7.1 Tax4Fun2功能预测#------

funcpath = paste(otupath,"/Tax4Fun2_Segetibacter/",sep = "")
dir.create(funcpath)
source("G:\\三人成师-培训资料汇总/第6期/micro\\runRefBlast2.R")
path_to_reference_data = "C:/public/Tax4Fun2/Tax4Fun2_ReferenceData_v2"
otudir = funcpath
#加载
library(Tax4Fun2)
#物种注释
#指定 OTU 代表序列、Tax4Fun2 库的位置、参考数据库版本、序列比对（blastn）线程数等
runRefBlast2(path_to_otus = './data_Segetibacter/otu.fa', 
             path_to_reference_data = path_to_reference_data, 
             path_to_temp_folder = otudir, 
             database_mode = 'Ref100NR', 
             use_force = TRUE,
             num_threads = 8)

#预测群落功能
#指定 OTU 丰度表、Tax4Fun2 库的位置、参考数据库版本、上步的物种注释结果路径等
?makeFunctionalPrediction

makeFunctionalPrediction(path_to_otu_table = './data/otu.txt',
                         path_to_reference_data = path_to_reference_data, 
                         path_to_temp_folder = otudir, 
                         database_mode = 'Ref100NR', 
                         normalize_by_copy_number = TRUE,
                         min_identity_to_reference = 0.97, 
                         normalize_pathways = FALSE)

library(ggClusterNet)
library(EasyStat)



#--基于通路#---------
#--功能预测-Tax4Fun2#----
ps0 = base::readRDS("./data/ps_16s_soil.rds")
#  定义分组
map = ps0 %>% sample_data()
head(map)
map$Group = map$group
map$Group %>% unique()
sample_data(ps0) = map

dat = read.delim(paste(funcpath,"/pathway_prediction.txt",sep = ""))
head(dat)
# colnames(dat)[2:28] = gsub("X","",colnames(dat)[2:28])


dat1 = dat %>% select(sample_names(ps0)) %>% as.data.frame()
row.names(dat1) = dat$pathway
library(phyloseq)

head(dat1)
tax =  dat %>% select("level1","level2","level3") %>% as.data.frame()
row.names(tax) = dat$pathway
ps = phyloseq(
  otu_table(as.matrix(dat1),taxa_are_rows = TRUE),
  sample_data(ps0),
  tax_table(as.matrix(tax))
)
ps

dir.create("./data/function.prediction/")
saveRDS(ps,paste(funcpath,"/ps_kegg_function.rds",sep = ""))
saveRDS(ps,"./data/function.prediction/ps_kegg_function.rds")



dat = read.delim(paste(funcpath,"/functional_prediction.txt",sep = ""))
head(dat)
# colnames(dat)[2:28] = gsub("X","",colnames(dat)[2:28])
ps0 

dat1 = dat %>% select(sample_names(ps0)) %>% as.data.frame()
row.names(dat1) = dat$KO
library(phyloseq)

head(dat1)

ps = phyloseq(
  otu_table(as.matrix(dat1),taxa_are_rows = TRUE),
  sample_data(ps0)
)
ps
saveRDS(ps,paste(funcpath,"/ps_kegg_gene.rds",sep = ""))
saveRDS(ps,"./data/function.prediction/ps_kegg_gene.rds")

map = ps %>% sample_data()
head(map)


# 基于通路
ps = readRDS("./data/function.prediction/ps_kegg_function.rds")
library(openxlsx)
id1 = read.xlsx("./data/工作簿1.xlsx")
head(id1)
tax_table(ps)

map =  sample_data(ps)

map$Group = map$group
sample_data(ps) = map
ps = ps %>%
  subset_taxa(
    row.names(tax_table(ps)) %in% id1$pathway
  )  
#--KO基因多样性分析#------
#axis_order = sample_data(ps)$Group %>%unique()

#--KEGG通路的排序分析--差异检测#------
betapath = paste(funcpath,"/beta_Function_筛选/",sep = "")
dir.create(betapath)

source("G:/圆桌会议/Metagenome_Function/BetaDiv__Meta.R")
source("G:/圆桌会议/Metagenome_Function/MicroTest_Meta.R")
source("G:/圆桌会议/Metagenome_Function//pairMicroTest_Meta.R")

map = sample_data(ps)
head(map)
# "unifrac" "wunifrac" "dpcoa" "jsd" "manhattan" "euclidean"   "canberra" "bray" "kulczynski" 
# "jaccard" "gower" "altGower" "morisita" "horn" "mountford"  "raup" "binomial" 
# "chao"  "cao" "w"  "-1"  "c" "wb"  "r"   "I"  "e" "t" "me"   "j"  "sor"  "m"   "-2"  "co"
# DCA, CCA, RDA, NMDS, MDS, PCoA, PCA, LDA

methodlist = c("NMDS","PCoA", "PCA")

for (method in methodlist) {
  result = BetaDiv(ps = ps, 
                   group = "Group",
                   dist = "bray", 
                   method = method, 
                   Micromet = "MRPP", 
                   pvalue.cutoff = 0.05)
  p3_1 = result[[1]] + 
    # scale_fill_manual(values = colset1)+
    # scale_color_manual(values = colset1,guide = F) +
    mytheme1 + 
    theme(legend.position = c(0.2,0.2))
  p3_1
  #带标签图形出图
  p3_2 = result[[3]] +
    # scale_fill_manual(values = colset1)+
    # scale_color_manual(values = colset1,guide = F) + 
    mytheme1 + 
    theme(legend.position = c(0.2,0.2))
  p3_2
  
  FileName <- paste(betapath,"/a2_",method,"bray.pdf", sep = "")
  ggsave(FileName, p3_1, width = 8, height = 8)
  FileName1 <- paste(betapath,"/a2_",method,"",method,"bray.jpg", sep = "")
  ggsave(FileName1 , p3_1, width = 12, height = 12)
  
  FileName <- paste(betapath,"/a2_",method,"bray_label.pdf", sep = "")
  ggsave(FileName, p3_2, width = 12, height = 12)
  FileName1 <- paste(betapath,"/a2_",method,"bray_label.jpg", sep = "")
  ggsave(FileName1 , p3_2, width = 12, height = 12)
  
  # 提取出图数据
  plotdata = result[[2]]
  FileName <-  paste(betapath,"/a2_",method,"bray.csv", sep = "")
  write.csv(plotdata,FileName)
  #---------排序-精修图
  plotdata =result[[2]]
  head(plotdata)
  # 求均值
  cent <- aggregate(cbind(x,y) ~Group, data = plotdata, FUN = mean)
  cent
  # 合并到样本坐标数据中
  segs <- merge(plotdata, setNames(cent, c('Group','oNMDS1','oNMDS2')),
                by = 'Group', sort = FALSE)
  
  # p2$layers[[2]] = NULL
  # library(ggcor)
  library(ggsci)
  p3_3 = p3_1 +geom_segment(data = segs,
                            mapping = aes(xend = oNMDS1, yend = oNMDS2,color = Group),show.legend=F) + # spiders
    geom_point(mapping = aes(x = x, y = y),data = cent, size = 5,pch = 24,color = "black",fill = "yellow") +
    # scale_fill_manual(values = colset1)+
    # scale_color_manual(values = colset1,guide = F) + 
    mytheme1 + 
    theme(legend.position = c(0.2,0.2))
  p3_3
  
  FileName <- paste(betapath,"/a2_",method,"bray_star.pdf", sep = "")
  ggsave(FileName, p3_3, width = 8, height = 8)
  FileName1 <- paste(betapath,"/a2_",method,"bray_star.jpg", sep = "")
  ggsave(FileName1 , p3_3, width = 8, height = 8)
  
}

#提取总体比较
TResult =result[[5]]
head(TResult)

# 提取两两检测结果
pair = result[[4]]
pair
FileName <- paste(betapath,"Pair_adonis.csv", sep = "")
write.csv(pair,FileName)
FileName <- paste(betapath,"Total_adonis.csv", sep = "")
write.csv(TResult,FileName)

library(phyloseq)
#-------功能门类展示#-----------
source("G:\\三人成师-培训资料汇总/第6期/micro/barMainplot_f.R")
barpath = paste(funcpath,"/Microbial_composition/",sep = "")
dir.create(barpath)
library(ggClusterNet)
rank_names(ps)
j = "leve1"
Top = 15
for (j in rank_names(ps)) {
  result = barMainplot(ps = ps,
                       j = j,
                        axis_ord = axis_order,
                       label = FALSE,
                       sd = FALSE,
                       Top = Top)
  p4_1 <- result[[1]] + 
    # scale_fill_brewer(palette = "Paired") + 
    scale_fill_manual(values = colset3) +
    scale_x_discrete(limits = axis_order) +
    mytheme1
  p4_1
  p4_2  <- result[[3]] + 
    # scale_fill_brewer(palette = "Paired") + 
    scale_fill_manual(values = colset3) +
    scale_x_discrete(limits = axis_order) +
    mytheme1
  p4_2
  
  databar <- result[[2]] 
  
  FileName1 <- paste(barpath,"/a2_",j,"_barflow",".pdf", sep = "")
  ggsave(FileName1, p4_2, width = (5+ gnum), height =8 )
  FileName2 <- paste(barpath,"/a2_",j,"_barflow",".jpg", sep = "")
  ggsave(FileName2, p4_2, width = (5+ gnum), height =8 )
  
  FileName1 <- paste(barpath,"/a2_",j,"_bar",".pdf", sep = "")
  ggsave(FileName1, p4_1, width = (5+ gnum), height =8 )
  FileName2 <- paste(barpath,"/a2_",j,"_bar",".jpg", sep = "")
  ggsave(FileName2, p4_1, width = (5+ gnum), height =8 )
  
  FileName <- paste(barpath,"/a2_",j,"_bar_data",".csv", sep = "")
  write.csv(databar,FileName)
}


# 热图展示------

sample_data(ps)
tax_table(ps)
otutab = as.data.frame((ggClusterNet::vegan_otu(ps) ))
ps_sub = ps 
sub_abu = t(otutab)

library(pheatmap)
sub_abu
map2 = map %>%as.tibble() 
map2$Group <- factor(map2$Group, levels = axis_order, ordered = TRUE)
map2 = arrange(map2,Group)

# 调整顺序
sub_abu = sub_abu[, match(map2$ID,colnames(sub_abu))]

row.names(sub_abu) = tax_table(ps)[,1]
# sub_abu[match(map2$SID,colnames(sub_abu)),]
sub_abu2 = sub_abu %>% t()%>% as.data.frame() 
row.names(sub_abu2)
# 
map2$Group %>% as.factor()
colnames(sub_abu) = paste(map2$Group,rep(1:9,3),sep = "")
head(sub_abu)
?pheatmap

map2$ID

p = pheatmap(sub_abu,  cluster_rows = FALSE,cluster_cols = F,scale = "row")

save_pheatmap_pdf <- function(x,filename,width=10, height=8){
  stopifnot(!missing(x))
  stopifnot(!missing(filename))
  pdf(filename,width=width,height=height)
  grid::grid.newpage()
  grid::grid.draw(x$gtable)
  dev.off()
}

barpath = paste(funcpath,"/热图/",sep = "")
dir.create(barpath)

FileName1 <- paste(barpath,"热图.pdf", sep = "")

save_pheatmap_pdf(p,FileName1,width=10, height=5)

nrow(sub_abu)

write.csv(sub_abu,"./result_and_plot/Base_diversity_16s/OTU差异/dif/差异.csv")


FileName <- paste(barpath,"热图",".csv", sep = "")
write.csv(sub_abu,FileName,quote = F)

# 组间均值
sample_data(ps)
otutab = as.data.frame((ggClusterNet::vegan_otu(ps)   ))
ps_sub = ps 
sub_abu = t(otutab)
library(pheatmap)
sub_abu

map2 = sample_data(ps_sub) %>%as.tibble()  
map2$Group <- factor(map2$Group, levels = axis_order[-1], ordered = TRUE)
map2 = arrange(map2,Group)
levels(map2$group)
# 调整顺序
map2
sub_abu2 = sub_abu[, match(map2$ID,colnames(sub_abu))] %>% as.data.frame()



sub_abu2$id = row.names(sub_abu2)


sub_abu3 = sub_abu2 %>% pivot_longer(cols = -id,names_to = "ID", values_to = "abundance")
head(sub_abu3)

map2
sub_abu3 = merge(sub_abu3,map2%>% select(ID,group), by= "ID") 
sub_abu4 = sub_abu3%>%
  group_by(group,id)%>%
  summarise(mean = mean(abundance))

head(sub_abu4)
# sub_abu[match(map2$SID,colnames(sub_abu)),]
sub_abu5 = sub_abu4 %>%  pivot_wider(names_from =id,
                                     values_from = mean) %>% as.data.frame()


row.names(sub_abu5) = sub_abu5$group
sub_abu5$group = NULL

sub_abu5 = t(sub_abu5) %>%as.data.frame() %>%select(Seedling_stage,vegetative_stage,flowering_stage,
                                                    fruit_stage) %>% as.matrix()

head(sub_abu5)

p=pheatmap(na.omit(sub_abu5), scale = "row",cluster_cols = F,cluster_rows = FALSE)
barpath

save_pheatmap_pdf(p,"./result_and_plot/Base_diversity_16s/OTU差异/dif/差异.pdf")
nrow(sub_abu)
write.csv(sub_abu,"./result_and_plot/Base_diversity_16s/OTU差异/dif/差异.csv")


FileName <- paste(barpath,"热图",".csv", sep = "")
write.csv(sub_abu,FileName,quote = F)

FileName1 <- paste(barpath,"热图",".pdf", sep = "")
ggsave(FileName1, p, width = 6, height =12 )


# 均值通路
sub_abu5 = read.xlsx("./data/通路富集均值.xlsx")

row.names(sub_abu5) = sub_abu5$ID

sub_abu5$ID=NULL

colnames(sub_abu5) = toupper(colnames(sub_abu5))

p= pheatmap(sub_abu5, scale = "row",cluster_cols = F,cluster_rows = FALSE)

FileName1 <- paste(barpath,"热图_均值.pdf", sep = "")

save_pheatmap_pdf(p,FileName1,width=6, height=3)


#--差异分析t检验-火山图#--------
diffpath = paste(funcpath,"/Different_Functional_pathway/",sep = "")
dir.create(diffpath)
diffpath = paste(funcpath,"/stemp_diff/",sep = "")
dir.create(diffpath)

source("G:/圆桌会议/Metagenome_Function/t.test__Meta.R")
sample_data(ps)

res = t.Fun(ps = ps,
            group  = "group",
            artGroup =NULL,
            path = diffpath)
head(res)

filename = paste(diffpath,"/","t_all_gene.csv",sep = "")
write.csv(res,filename)


#---wlx.Fun非参数检验#——-----
source("G:/圆桌会议/Metagenome_Function/wlx.Fun_Meta.R")
wlx.Fun(ps = ps,group  = "Group",artGroup =NULL,
        path = diffpath
)
head(res)

filename = paste(diffpath,"/","wlx_all_gene.csv",sep = "")
write.csv(res,filename)


#---------stemp_差异分析#------
source("E:\\Shared_Folder\\Function_local\\R_function\\Metagenome_Function/st.R")

diffpath = paste(funcpath,"/stemp_diff/",sep = "")
dir.create(diffpath)
# https://mp.weixin.qq.com/s/DTOz37JgH80kuLNi6Ae6-g

allgroup <- combn(unique(sample_data(ps)$Group),2)

for (i in 1:dim(allgroup)[2]) {
    ps_sub <- subset_samples(ps,Group %in% allgroup[,i]);ps_sub
    p <- stemp_diff(ps = ps_sub,Top = 20,ranks = j)
    p
    filename = paste(diffpath,"/",paste(allgroup[,i][1],
                                        allgroup[,i][2],sep = "_"),"stemp_plot.pdf",sep = "")
    ggsave(filename,p,width = 14,height = 6)
    
    filename = paste(diffpath,"/",paste(allgroup[,i][1],
                                        allgroup[,i][2],sep = "_"),"stemp_plot.jpg",sep = "")
    ggsave(filename,p,width = 14,height = 6)

}



#----网络分析#-----------
source("E:/Shared_Folder/Function_local/R_function/Metagenome_Function/networkplot_Meta.R")

netpath = paste(funcpath,"/network/",sep = "")
dir.create(netpath)

library(igraph)
library(sna)


sample_data(ps)

result =network.2(ps = ps, 
                     N = 0,
                     r.threshold=0.8,
                     p.threshold=0.05,
                     label = FALSE,
                  big = TRUE,
                     path = netpath,
                     zipi = F,
                     ncol = gnum,
                     nrow = 1,
                     # method = "sparcc",
                     fill = "level3",
                  select_layout = TRUE,
                  layout_net = "model_maptree2"
)

gnum = length(axis_order)
# 全部样本的网络比对
p4_1 = result[[1]] + scale_fill_brewer(palette = "Paired") 
p4_1
# 全部样本网络参数比对
data = result[[2]]

plotname1 = paste(netpath,"/network_all.pdf",sep = "")
ggsave(plotname1, p4_1,width = 16*gnum,height = 16,limitsize = FALSE)
# plotname1 = paste(netpath,"/network_all.jpg",sep = "")
# ggsave(plotname1, p4_1,width = 16*gnum,height = 16)

tablename <- paste(netpath,"/co-occurrence_Grobel_net",".csv",sep = "")
write.csv(data,tablename)



#---------基于基因#---------
ps = readRDS("./data/")
map = ps %>% sample_data()
head(map)

#--KO基因多样性分析#------
axis_order = sample_data(ps)$Group %>%unique()


#--基因差异分析t检验#-----------
source("E:/Shared_Folder/Function_local/R_function/Metagenome_Function/t.test__Meta.R")
diffpath = paste(funcpath,"/gene_difference/",sep = "")
dir.create(diffpath)
res = t.Fun(ps = ps,group  = "Group",artGroup =NULL,
            path = diffpath
)
head(res)

filename = paste(diffpath,"/","t_all_gene.csv",sep = "")
write.csv(res,filename)


#---KEGG通路富集#------
source("E:/Shared_Folder/Function_local/R_function/Metagenome_Function/KEGG_enrich_Meta.R",encoding = "utf-8")
# BiocManager::install("GSVA")
enrichpath = paste(funcpath,"/pathway_enrich/",sep = "")
dir.create(enrichpath)
KEGG_enrich(ps = ps,
            diffpath = diffpath,
            enrichpath = enrichpath
            
)


buplotall( ps = ps,diffpath = diffpath,
           enrichpath = enrichpath)



#--------可选，功能预测不选#-------
#--差异分析edger#----
diffpath = paste(funcpath,"/Different_Functional_pathway/",sep = "")
dir.create(diffpath)
# 准备脚本
source("E:/Shared_Folder/Function_local/R_function/Metagenome_Function/EdgerSuper_Meta.R")
# source("E:/Shared_Folder/Function_local/R_function/Metagenome_Function/Plot.CompareWithCK.R",encoding = "utf-8")

res = EdgerSuper(ps = ps,
                 group  = "Group",
                 artGroup = NULL,
                 j = "OTU",
                 path = diffpath
)
head(res)
head(res)
filename = paste(diffpath,"/","Edger_all_gene.csv",sep = "")
write.csv(res,filename)


#--差异分析DEsep2#------------
# source("E:/Shared_Folder/Function_local/R_function/Metagenome_Function/t.test__Meta.R")
# DESep2_Meta(ps = ps,group  = "Group",artGroup =NULL,
#             path = diffpath
# )
# head(res)
# filename = paste(diffpath,"/","DESep2_all_gene.csv",sep = "")
# write.csv(res,filename)



